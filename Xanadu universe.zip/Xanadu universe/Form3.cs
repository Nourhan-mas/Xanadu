﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xanadu_universe
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }


        class ZZ
        {
            private Label reply;
            public static void speakfrench(Label reply)
            {
                reply.Text = "I can't Speak French!";
            }

            public static void eat(Label reply)
            {
                reply.Text = "I can't eat!";
            }
            public static void sing(Label reply)
            {
                reply.Text = "I can sing when i socialize!";
            }
            public static void snore(Label reply)
            {
                reply.Text = "I can't snore!";
            }
            public static void icodecsharp(Label reply)
            {
                reply.Text = "I can't code in C#";
            }
            public static void dance(Label reply)
            {
                reply.Text = "I can dance when I socialize";
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            ZZ.speakfrench(reply);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ZZ.eat(reply);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ZZ.snore(reply);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ZZ.icodecsharp(reply);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
                ZZ.dance(reply);
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ZZ.sing(reply);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void reply_Click(object sender, EventArgs e)
        {

        }
    }
}
