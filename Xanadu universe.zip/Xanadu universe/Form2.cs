﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xanadu_universe
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

        }
      

        class YY
        {
            private Label reply;
            public static void speakfrench(Label reply)
            {
                reply.Text = "I can Speak French";
            }
  
            public static void eat(Label reply)
            {
                reply.Text = "I can eat";
            }
            public static void sing(Label reply)
            {
                reply.Text = "I can't Sing";
            }
            public static void snore(Label reply)
            {
                reply.Text = "I don't snore";
            }
            public static void icodecsharp(Label reply)
            {
                reply.Text = "I can't Code C#";
            }
            public static void dance(Label reply)
            {
                reply.Text = "I can't Dance!";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }



        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            YY.speakfrench(reply);
        }
       


        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void humanoid_reply_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            YY.sing(reply);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            YY.eat(reply);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            YY.snore(reply);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            YY.icodecsharp(reply);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            YY.dance(reply);
        }
    }
   
}

