﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xanadu_universe
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        class ZZ
        {
            private Label reply;
            public static void speakfrench(Label reply)
            {
                reply.Text = "I can't Speak French!";
            }

            public static void eat(Label reply)
            {
                reply.Text = "I can't eat!";
            }
            public static void sing(Label reply)
            {
                reply.Text = "I can sing when i socialiaze!";
            }
            public static void snore(Label reply)
            {
                reply.Text = "I can't snore!";
            }
            public static void icodecsharp(Label reply)
            {
                reply.Text = "I can't code in C#";
            }
            public static void dance(Label reply)
            {
                reply.Text = "I can dance when I socialize";
            }
        }
        class NN : ZZ
        {
            private Label reply;
            public static void sing(Label reply)
            {
                reply.Text = "I like to sing when i socialize!";
            }


        }
  
        private void button1_Click(object sender, EventArgs e)
        {
            NN.speakfrench(reply);
        }

     
      

        private void button7_Click(object sender, EventArgs e)
        {
            NN.sing(reply);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NN.eat(reply);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            NN.snore(reply);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            NN.icodecsharp(reply);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            NN.dance(reply);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            mother.Visible = true;
            reply.Text = "this is my ancestor";
        }

        private void mother_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
